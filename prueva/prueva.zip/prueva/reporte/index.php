<?php

require('../fpdf/fpdf.php');
require('../model/venta1.php');
$model = new VentasSanJuan1();
$pdf = new FPDF();
$pdf->AliasNbPages();
$pdf->AddPage();
  
    $pdf->SetFont('Arial','B',15);
	$pdf->Cell(30);
	$pdf->Cell(120,10,utf8_decode($_POST['FechaInicios']),0,0,'C');
	$pdf->Ln(20);

	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',12);
	foreach ($model->ExtraerDatosCaja() as $r) 
	{
$pdf->Cell(40,6,'Nombre del Cajero(a):_______________________________',0,0,'L',0);
	$pdf->Cell(80,6,utf8_decode($r->Codigo),0,0,'C');
	}
	
	$pdf->Cell(10,6,'Turno :___________________',0,0,'L',0);
	$pdf->Cell(0,6,utf8_decode($_POST['SucursalBs']),0,0,'C');
	$pdf->Ln(9);
	$pdf->Cell(16,6,'Hora Entrada:_____________',0,0,'L',0);
	$pdf->Cell(47,6,utf8_decode('sleiter'),0,0,'C');
	$pdf->Cell(15,6,'Hora Salida:_____________',0,0,'L',0);
	$pdf->Cell(43,6,utf8_decode('sleiter'),0,0,'C');
	$pdf->Cell(15,6,'Fecha:___________________',0,0,'L',0);
	$pdf->Cell(0,6,utf8_decode('sleiter'),0,0,'C');
    $pdf->Ln(10);
$pdf->OutPut();
?>
